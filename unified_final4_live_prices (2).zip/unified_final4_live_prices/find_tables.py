import pyodbc

conn = pyodbc.connect(
    "Driver={ODBC Driver 18 for SQL Server};"
    "Server=fcedata01.fieracapital.ca;"
    "Database=CCL_Intranet;"
    "Trusted_Connection=yes;"
    "TrustServerCertificate=yes;"
)
cursor = conn.cursor()

# List all tables with row counts
cursor.execute("""
    SELECT 
        t.TABLE_SCHEMA,
        t.TABLE_NAME,
        p.rows
    FROM INFORMATION_SCHEMA.TABLES t
    JOIN sys.partitions p 
        ON p.object_id = OBJECT_ID(t.TABLE_SCHEMA + '.' + t.TABLE_NAME)
        AND p.index_id IN (0, 1)
    WHERE t.TABLE_TYPE = 'BASE TABLE'
    ORDER BY p.rows DESC
""")

for row in cursor.fetchall():
    print(f"{row[0]}.{row[1]:<50} rows: {row[2]}")